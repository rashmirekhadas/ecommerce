package com.niit.MyfirstprojectBackend.dao;

import com.niit.MyfirstprojectBackend.model.User;

public interface UserDAO {
	
	boolean add(User user);
	

}
